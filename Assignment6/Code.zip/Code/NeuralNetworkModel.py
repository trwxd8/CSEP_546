import numpy as np

class NeuralNetworkModel(object):
    """A model that predicts the most common label from the training data."""

    def __init__(self, hiddenLayerCount, hiddenLayerSize, inputLen):
        self.layerCount = hiddenLayerCount
        self.layerSize = hiddenLayerSize
        print("print (", hiddenLayerCount+1,",",hiddenLayerSize+1,",",inputLen,")")
        self.nodeWeight = []#np.ndarray((hiddenLayerCount+1, hiddenLayerSize+1, inputLen))
        #Go through each node
        for i in range(hiddenLayerCount):
            #Determine how many weight values to initialize
            # +1 for x_0 = 1
            if i == 0:
                weightCnt = inputLen + 1
            else:
                weightCnt = hiddenLayerSize + 1
            currLayer = []
            #self.nodeWeight.append(np.empty(weightCnt, hiddenLayerSize))
            for j in range(hiddenLayerSize):

        		#Create random weights bounded between -.05 and .05
                #print("At ",i,",",j," - ",weightCnt)
                currLayer.append(np.multiply(np.subtract(np.random.ranf(weightCnt), .5), .1))
            self.nodeWeight.append(currLayer)
        #self.nodeWeight[1][hiddenLayerCount] = np.multiply(np.subtract(np.random.ranf(weightCnt), .5), .1)
        print(self.nodeWeight)

    def fit(self, xTrain, yTrain, iterations, step):
        trainLen = len(xTrain)
        inputLen = len(xTrain[0])
        for curr_iter in range(iterations):
            for i in trainLen:
                sample = xTrain[i]
                answer = yTrain[i]
                prediction = self.ForwardPropogation(sample)
                #error =  np.abs(prediction - answer)
                self.BackwardsPropogation(prediction, answer, inputLen, step)
        pass

    def ForwardPropogation(self, sample):
        #Make sample 1D?
        nodeInputs = np.insert(np.asarray(sample), 0, 1)
        for layer in range(self.layerCount):
            print(nodeInputs)
            print(self.nodeWeight)
            newInputs = [1]
            print("Layer ",layer,":")
            for node in range(self.layerSize):
                nodeValue = self.calculateSigmoids(nodeInputs, self.nodeWeight[layer][node])
                print("Node ",node,": ",nodeValue)
                newInputs.append(nodeValue)
            nodeInputs = newInputs
        
        nodeValue = self.calculateSigmoids(nodeInputs, self.nodeWeight[self.layerCount][0])
        print("Prediction:",nodeValue)
        return 1

    def calculateSigmoids(self, x, weights):
        print("input:",x)
        print("weights:", weights)
        return np.divide(1.0, np.add(1.0, np.exp(np.multiply(-1.0, np.dot(x, weights)))))

    def BackwardsPropogation(self, prediction, answer, inputLen, step):
        currErrors = []

        error =  self.ErrorFunction(prediction, answer)
        currErrors.append(error)

        for currLayer in range(self.layerCount - 1, -1, -1):
            if currLayer == 0:
                weightCnt = inputLen + 1
            else:
                weightCnt = self.layerSize + 1
            newErrors = []
            for currNode in range(self.layerSize):
                for error in currErrors:
                    for wIdx in weightCnt:
                        adjustedWeight = error * step *  self.nodeWeight[currLayer][currNode][wIdx]   
                        self.nodeWeight[currLayer][currNode][wIdx] += adjustedWeight 
                newErrors.append([])
            currErrors = newErrors          

        pass

    def ErrorFunction(self, prediction, answer):
        return prediction * (1 - prediction) * (answer - prediction)

    def UnitTest(self):
        self.layerCount = 1
        self.layerSize = 2
        self.nodeWeight = np.array([[[.5, -1.0, 1.0], [1.0, 0.5, -1.0]],
                           [[.25, 1.0, 1.0], [-1, -1, -1]]])

        sample = np.array([1.0, 0.5])
        self.ForwardPropogation(sample)