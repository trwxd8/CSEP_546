import random as rand
import math
import numpy as np
class KMeansClustering(object):
    def __init__(self, k):
        self.K = k
        self.centroids = np.array()
        for i in range(k):
            self.centroids.append(np.array([rand.random(), rand.random()]), axis=0)
        print(self.centroids)
    
    def fit(self, x):
        centroidDatasets = []
        for i in range(self.K):
            centroidDatasets.append([])

        for example in x:
            closestCentroid = -1
            closestDistance = 10
            for i in range(self.K):
                dist = self.distance(self.centroids[i], example)
                if dist < closestDistance:
                    closestCentroid = i
                    closestDistance = dist
            centroidDatasets[closestCentroid].append(example)

        """for example in x:
            dists = self.distance(example)

       def distance(self, x):
            return np.sqrt(np.sum(np.subtract(x, self.centroids)))"""

    def distance(self, centroid, sample):
        d1 = sample[0] - centroid.X
        d2 = sample[1] - centroid.Y

        return math.sqrt(d1**2 + d2**2)

    def loss(self, x, currIdx):
        meanLoc = [0,0]
        cnt = len(x)
        for sample in x:
            meanLoc[0] += sample[0]
            meanLoc[1] += sample[1]
        meanLoc /= cnt
        self.centroids[currIdx] = meanLoc

class KNearestNeightbors(object):
    def __init__(self, k):
        pass

class Index(object):
    def __init__(self, x, y):
        self.X = x
        self.Y = y